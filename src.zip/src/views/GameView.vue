<template>
  <div class="game">
    <GameComponent v-if="selectedGame" :game="selectedGame" />
  </div>
</template>

<script>
import GameComponent from '@/components/GameComponent.vue';

export default {
  name: 'GameView',
  components: {
    GameComponent
  },
  data() {
    return {
      selectedGame: null
    };
  },
  methods: {
    selectGame(game) {
      this.selectedGame = game;
    }
  }
}
</script>

<style scoped>
.game {
  padding: 20px;
}
</style>
