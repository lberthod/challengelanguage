<template>
    <div class="features-list">
      <h2>Fonctionnalités Principales</h2>
      <ul>
        <li>Mini-jeux éducatifs</li>
        <li>Défis multijoueurs</li>
        <li>Progression et récompenses</li>
      </ul>
    </div>
  </template>
  
  <script>
  export default {
    name: 'FeaturesListComponent'
  }
  </script>
  
  <style scoped>
  .features-list {
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background-color: #f9f9f9;
  }
  </style>
  