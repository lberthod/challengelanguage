<template>
    <div class="multiplayer-lobby">
      <h2>Salle d'Attente Multijoueur</h2>
      <!-- Logique pour afficher les joueurs dans la salle d'attente -->
    </div>
  </template>
  
  <script>
  export default {
    name: 'MultiplayerLobbyComponent'
  }
  </script>
  
  <style scoped>
  .multiplayer-lobby {
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background-color: #f9f9f9;
  }
  </style>
  