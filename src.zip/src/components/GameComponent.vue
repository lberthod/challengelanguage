<template>
    <div class="game-component">
      <h2>Jeu Sélectionné</h2>
      <!-- Logique pour le jeu sélectionné -->
       fd
    </div>
  </template>
  
  <script>
  export default {
    name: 'GameComponent',
    props: {
      game: Object
    }
  }
  </script>
  
  <style scoped>
  .game-component {
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background-color: #f9f9f9;
  }
  </style>
  