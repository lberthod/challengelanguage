<template>
    <div class="user-profile">
      <h2>Profil Utilisateur</h2>
      <p><strong>Nom:</strong> John Doe</p>
      <p><strong>Email:</strong> john.doe@example.com</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'UserProfileComponent'
  }
  </script>
  
  <style scoped>
  .user-profile {
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background-color: #f9f9f9;
  }
  </style>
  