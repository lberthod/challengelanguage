<template>
    <div class="hero-banner">
      <h1>Bienvenue à Langue Challenge</h1>
      <p>Apprenez les langues de manière ludique et interactive !</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'HeroBannerComponent'
  }
  </script>
  
  <style scoped>
  .hero-banner {
    text-align: center;
    padding: 50px;
    background-color: #42b983;
    color: white;
  }
  </style>
  